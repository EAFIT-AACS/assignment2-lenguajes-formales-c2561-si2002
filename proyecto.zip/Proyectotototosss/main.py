from fastapi import FastAPI, Request, Form
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
import logica

app = FastAPI()

app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

@app.get("/", response_class=HTMLResponse)
def read_index(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

@app.post("/verificar", response_class=HTMLResponse)
async def verificar(request: Request, entrada: str = Form(...)):
    resultado = "✅ Cadena válida" if logica.verificar_cadena(entrada) else "❌ Cadena inválida"
    return templates.TemplateResponse("index.html", {"request": request, "resultado": resultado})

@app.post("/simular", response_class=HTMLResponse)
async def simular(request: Request, entrada: str = Form(...)):
    resultado = logica.simular_automata_pila(entrada)
    return templates.TemplateResponse("index.html", {"request": request, "resultado": resultado})

@app.post("/derivar", response_class=HTMLResponse)
async def derivar(request: Request, entrada: str = Form(...)):
    derivacion = logica.mostrar_derivacion_leftmost(entrada)
    resultado = "\n".join(derivacion)
    return templates.TemplateResponse("index.html", {"request": request, "resultado": resultado})
