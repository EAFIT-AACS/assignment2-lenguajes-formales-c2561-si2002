def verificar_cadena(cadena):
    pila = []
    for char in cadena:
        if char == 'a':
            pila.append('X')
        elif char == 'b':
            if pila:
                pila.pop()
            else:
                return False
    return len(pila) == 0

def simular_automata_pila(cadena):
    pila = []
    salida = []

    for i, char in enumerate(cadena):
        cadena_restante = cadena[i:]
        paso = f"Paso {i+1}: Leyendo '{char}'\n"
        paso += f"Cadena restante: {cadena_restante}\n"
        paso += f"Pila antes: {pila}\n"

        if char == 'a':
            pila.append('X')
        elif char == 'b':
            if pila:
                pila.pop()
            else:
                paso += "❌ Error: pila vacía. Cadena rechazada."
                salida.append(paso)
                return "\n".join(salida)

        paso += f"Pila después: {pila}\n"
        salida.append(paso)

    salida.append("✅ Cadena aceptada" if not pila else "❌ Cadena rechazada")
    return "\n\n".join(salida)

def mostrar_derivacion_leftmost(cadena):
    n = len(cadena) // 2
    derivacion = ["S"]

    if n > 1:
        derivacion.append("AC")
    else:
        derivacion.append("AB")

    while True:
        ultima = derivacion[-1]
        nueva = list(ultima)

        if "A" in nueva:
            nueva[nueva.index("A")] = "a"
        elif "S" in nueva:
            idx_s = nueva.index("S")
            if nueva[:idx_s].count("a") < (n - 1):
                nueva[idx_s:idx_s+1] = list("AC")
            else:
                nueva[idx_s:idx_s+1] = list("AB")
        elif "C" in nueva:
            nueva[nueva.index("C")] = "SB"
        elif "B" in nueva:
            nueva[nueva.index("B")] = "b"
        else:
            break

        derivacion.append("".join(nueva))

    return derivacion
